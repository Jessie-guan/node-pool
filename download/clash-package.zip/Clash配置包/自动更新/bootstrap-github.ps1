﻿# ============================================================
# bootstrap-github.ps1 —— 只需要一个 Token，全自动完成：
#   1) 用 API 创建 Public 仓库
#   2) 推送 pipeline 代码（含 GitHub Actions 配置）
#   3) 打开 Actions 权限
#   4) 触发第一次运行
#   5) 轮询状态，跑完打印订阅地址
#
# 用法：
#   powershell -ExecutionPolicy Bypass -File .\bootstrap-github.ps1 -Token ghp_xxxx
#   powershell -ExecutionPolicy Bypass -File .\bootstrap-github.ps1 -Token ghp_xxxx -Repo my-pool
#
# Token 获取（30 秒）：
#   https://github.com/settings/tokens → Generate new token (classic)
#   → 勾选 repo → Generate token → 复制
# ============================================================
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Token,
    [string]$Repo = 'node-pool',
    [string]$Branch = 'main',
    [switch]$SkipRun
)

$ErrorActionPreference = 'Continue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Say($m) { Write-Host "[*] $m" -ForegroundColor Cyan }
function Ok($m)  { Write-Host "[OK] $m" -ForegroundColor Green }
function Bad($m) { Write-Host "[!!] $m" -ForegroundColor Yellow }

$H = @{
    Authorization          = "token $Token"
    Accept                 = 'application/vnd.github+json'
    'User-Agent'           = 'dsh-bootstrap'
    'X-GitHub-Api-Version' = '2022-11-28'
}

function Api($method, $path, $body = $null) {
    $p = @{
        Uri         = "https://api.github.com$path"
        Method      = $method
        Headers     = $H
        ContentType = 'application/json'
    }
    if ($body) { $p.Body = ($body | ConvertTo-Json -Depth 6) }
    try {
        return Invoke-RestMethod @p
    } catch {
        $msg = $_.Exception.Message
        try {
            $r = $_.Exception.Response
            $sr = New-Object System.IO.StreamReader($r.GetResponseStream())
            $detail = $sr.ReadToEnd()
            Bad "API $method $path 失败: $detail"
        } catch {
            Bad "API $method $path 失败: $msg"
        }
        return $null
    }
}

# ---------- 1. 验证 token，拿用户名 ----------
Say '验证 Token'
$me = Api 'GET' '/user'
if (-not $me) {
    Bad 'Token 无效或没有 repo 权限。重新生成时务必勾选 repo'
    exit 1
}
$user = $me.login
Ok "账号: $user"

# ---------- 2. 创建仓库 ----------
Say "创建仓库 $user/$Repo（Public）"
$exist = Api 'GET' "/repos/$user/$Repo"
if ($exist) {
    Ok "仓库已存在，直接使用"
} else {
    $created = Api 'POST' '/user/repos' @{
        name        = $Repo
        private     = $false
        auto_init   = $false
        description = 'daily auto-cleaned free node pool for clash/mihomo'
    }
    if (-not $created) { exit 1 }
    Ok '仓库已创建'
}

# ---------- 3. 用 API 上传代码（不依赖 git） ----------
Say '上传代码（走 GitHub API，不需要 git）'

$src = Join-Path $PSScriptRoot 'pipeline'
if (-not (Test-Path $src)) { Bad "找不到 $src"; exit 1 }

$skipDirs  = @('_work', '__pycache__')
$skipFiles = @('pool.json', 'alive.json')

function Upload-File {
    param([string]$RelPath, [string]$LocalPath)
    $bytes = [System.IO.File]::ReadAllBytes($LocalPath)
    $b64   = [Convert]::ToBase64String($bytes)

    $sha = $null
    $existing = Api 'GET' "/repos/$user/$Repo/contents/$RelPath`?ref=$Branch"
    if ($existing -and $existing.sha) { $sha = $existing.sha }

    $body = @{ message = "add: $RelPath"; content = $b64; branch = $Branch }
    if ($sha) { $body.sha = $sha }

    $r = Api 'PUT' "/repos/$user/$Repo/contents/$RelPath" $body
    if ($r) { Ok "  $RelPath" } else { Bad "  $RelPath 失败" }
    return ($null -ne $r)
}

$files = Get-ChildItem -Path $src -Recurse -File | Where-Object {
    $rel = $_.FullName.Substring($src.Length).TrimStart('\', '/')
    $parts = $rel -split '[\\/]'
    (-not ($parts | Where-Object { $_ -in $skipDirs })) -and ($_.Name -notin $skipFiles)
}

Say "待上传 $($files.Count) 个文件"
$okCount = 0
foreach ($f in $files) {
    $rel = $f.FullName.Substring($src.Length).TrimStart('\', '/') -replace '\\', '/'
    if (Upload-File -RelPath $rel -LocalPath $f.FullName) { $okCount++ }
    Start-Sleep -Milliseconds 350
}
Ok "上传完成：$okCount / $($files.Count)"

# ---------- 4. 打开 Actions ----------
Say '启用 Actions'
$perm = Api 'PUT' "/repos/$user/$Repo/actions/permissions" @{ enabled = $true; allowed_actions = 'all' }
if ($perm -ne $null) { Ok 'Actions 已启用' } else { Bad '启用失败（可能需要在网页上点一下确认）' }

# 给 workflow 写权限（让 Actions 能 commit 回仓库）
Api 'PUT' "/repos/$user/$Repo/actions/permissions/workflow" @{
    default_workflow_permissions = 'write'
    can_approve_pull_request_reviews = $false
} | Out-Null
Ok '已授予 workflow 写权限'

# ---------- 5. 触发第一次 ----------
if (-not $SkipRun) {
    Say '触发第一次运行'
    Start-Sleep -Milliseconds 3000
    $disp = Api 'POST' "/repos/$user/$Repo/actions/workflows/daily.yml/dispatches" @{ ref = $Branch }
    if ($disp -eq $null) {
        Bad '触发失败（可能 Actions 还没就绪），30 秒后重试'
        Start-Sleep -Milliseconds 5000
        Api 'POST' "/repos/$user/$Repo/actions/workflows/daily.yml/dispatches" @{ ref = $Branch } | Out-Null
    }
    Ok '已触发，开始轮询状态'

    # ---------- 6. 轮询 ----------
    $run = $null
    for ($i = 0; $i -lt 12; $i++) {
        Start-Sleep -Milliseconds 5000
        $runs = Api 'GET' "/repos/$user/$Repo/actions/runs?per_page=3"
        if ($runs -and $runs.workflow_runs.Count -gt 0) {
            $run = $runs.workflow_runs[0]
            Say ("状态: {0} / {1}" -f $run.status, $run.conclusion)
            if ($run.status -eq 'completed') { break }
        }
    }

    if ($run) {
        Write-Host ''
        if ($run.conclusion -eq 'success') {
            Ok "第一次运行成功（耗时约 $([int](($run.updated_at - $run.created_at).TotalMinutes)) 分钟）"
        } elseif ($run.status -eq 'completed') {
            Bad "运行结束但结论是 $($run.conclusion)，去这里看日志：$($run.html_url)"
        } else {
            Say "还在跑，进度看这里：$($run.html_url)"
        }
    }
}

# ---------- 7. 输出订阅地址 ----------
Write-Host ''
Write-Host '════════════════════════════════════════' -ForegroundColor Green
Write-Host ' 订阅地址（任选一个）' -ForegroundColor Green
Write-Host '════════════════════════════════════════' -ForegroundColor Green
$raw = "https://raw.githubusercontent.com/$user/$Repo/$Branch/dist/clash.yaml"
Write-Host "直连:   $raw"
Write-Host "加速1:  https://ghfast.top/$raw"
Write-Host "加速2:  https://cdn.jsdelivr.net/gh/$user/$Repo@$Branch/dist/clash.yaml"
Write-Host ''
Write-Host 'Actions 页面: ' -NoNewline
Write-Host "https://github.com/$user/$Repo/actions" -ForegroundColor Cyan
Write-Host ''
Write-Host 'FlClash 里操作：' -ForegroundColor Yellow
Write-Host '  配置 → 右上 + → 链接 → 长按粘贴上面的地址 → 保存' -ForegroundColor Yellow
Write-Host '  然后长按该配置 → 编辑 → 自动更新改成 6 小时' -ForegroundColor Yellow
Write-Host ''
Write-Host '安全提示：跑完可以去 https://github.com/settings/tokens 把这个 token 删掉，' -ForegroundColor DarkGray
Write-Host '         流水线用的是仓库自带的 GITHUB_TOKEN，不需要你这个。' -ForegroundColor DarkGray
