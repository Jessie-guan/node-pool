#!/usr/bin/env bash
# ============================================================
# deploy-hy2-4k.sh —— 一键部署 Hysteria2 + 自动生成 mihomo 配置
# 适用: Ubuntu 20.04/22.04/24.04 (Oracle Always Free ARM / 任意 VPS)
# 用法: sudo bash deploy-hy2-4k.sh
# 自定义: sudo DOWN=300 UP=100 PASS=MyPass123 SNI=bing.com bash deploy-hy2-4k.sh
# 产出: /root/clash-meta-4k.yaml   /root/hy2-link.txt
# ============================================================
set -euo pipefail
[[ ${EUID} -ne 0 ]] && exec sudo -E bash "$0" "$@"

PASS="${PASS:-BaBa4K2026}"
SNI="${SNI:-bing.com}"
UP="${UP:-60}"                 # 上行 = 家宽上行 × 0.6
DOWN="${DOWN:-180}"            # 下行 = 家宽下行 × 0.6
PORT="${PORT:-443}"
HOP="${HOP:-20000:30000}"      # 端口跳跃区间
OUT="/root/clash-meta-4k.yaml"
LINKF="/root/hy2-link.txt"

say() { printf '\n\033[1;36m[%s]\033[0m %s\n' "$1" "$2"; }

say 1/8 "内核调优 (BBR + fq + 大缓冲)"
cat > /etc/sysctl.d/99-hy2-4k.conf <<'EOF'
net.core.default_qdisc=fq
net.ipv4.tcp_congestion_control=bbr
net.core.rmem_max=16777216
net.core.wmem_max=16777216
net.ipv4.ip_forward=1
EOF
sysctl --system >/dev/null

say 2/8 "安装 Hysteria2"
if ! command -v hysteria >/dev/null 2>&1; then
  bash <(curl -fsSL https://get.hy2.sh/)
else
  echo "  已安装: $(hysteria version 2>/dev/null | head -1)"
fi

say 3/8 "生成自签证书 (CN=${SNI})"
mkdir -p /etc/hysteria
openssl req -x509 -nodes -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 \
  -keyout /etc/hysteria/server.key -out /etc/hysteria/server.crt \
  -subj "/CN=${SNI}" -days 3650 2>/dev/null
chmod 600 /etc/hysteria/server.key

say 4/8 "写入 /etc/hysteria/config.yaml"
cat > /etc/hysteria/config.yaml <<EOF
listen: :${PORT}

tls:
  cert: /etc/hysteria/server.crt
  key: /etc/hysteria/server.key

auth:
  type: password
  password: ${PASS}

bandwidth:
  up: ${UP} mbps
  down: ${DOWN} mbps

quic:
  initStreamReceiveWindow: 8388608
  maxStreamReceiveWindow: 8388608
  initConnReceiveWindow: 20971520
  maxConnReceiveWindow: 20971520

ignoreClientBandwidth: false

masquerade:
  type: proxy
  proxy:
    url: https://www.bing.com
    rewriteHost: true
EOF
echo "  已写入，bandwidth up=${UP} / down=${DOWN} mbps"

say 5/8 "配置端口跳跃 + 防火墙"
IFACE=$(ip -4 route ls default | grep -Po '(?<=dev )\S+' | head -1)
iptables -t nat -C PREROUTING -i "${IFACE}" -p udp --dport "${HOP}" -j REDIRECT --to-ports "${PORT}" 2>/dev/null || \
  iptables -t nat -A PREROUTING -i "${IFACE}" -p udp --dport "${HOP}" -j REDIRECT --to-ports "${PORT}"
if [[ "${HOP}" == *":"* ]]; then
  UFW_RANGE="${HOP/:/-}"
else
  UFW_RANGE="${HOP}"
fi
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow "${PORT}/udp" >/dev/null 2>&1 || true
  ufw allow "${UFW_RANGE}/udp" >/dev/null 2>&1 || true
fi
if ! command -v netfilter-persistent >/dev/null 2>&1; then
  DEBIAN_FRONTEND=noninteractive apt-get install -y iptables-persistent >/dev/null 2>&1 || true
fi
netfilter-persistent save >/dev/null 2>&1 || true
echo "  网卡=${IFACE} 跳跃=${HOP} → 落地=${PORT}"

say 6/8 "启动服务"
systemctl enable --now hysteria-server.service >/dev/null 2>&1 || systemctl enable --now hysteria.service
sleep 2
if systemctl is-active --quiet hysteria-server.service 2>/dev/null || systemctl is-active --quiet hysteria.service 2>/dev/null; then
  echo "  运行中 ✓"
else
  echo "  启动异常，最近日志："
  journalctl -u hysteria-server -u hysteria -n 20 --no-pager 2>/dev/null || true
fi

say 7/8 "探测公网 IP"
IP=$(curl -4 -fsS --max-time 8 https://api.ipify.org 2>/dev/null || true)
if [[ -z "${IP}" ]]; then
  IP=$(curl -4 -fsS --max-time 8 http://169.254.169.254/opc/v1/vnics/ 2>/dev/null \
       | grep -o '"publicIp":"[^"]*"' | head -1 | cut -d'"' -f4 || true)
fi
if [[ -z "${IP}" ]]; then
  IP=$(curl -4 -fsS --max-time 8 https://ifconfig.me 2>/dev/null || true)
fi
[[ -z "${IP}" ]] && { echo "  探测失败，请手动填入 IP"; IP="你的服务器IP"; }
echo "  公网 IP = ${IP}"

say 8/8 "生成客户端配置 → ${OUT}"

calc_up()   { printf '%s Mbps' "${UP}"; }
calc_down() { printf '%s Mbps' "${DOWN}"; }

cat > "${OUT}" <<EOF
# mihomo / Clash Meta —— 由 deploy-hy2-4k.sh 自动生成
# 导入: ClashMetaForAndroid / Clash Verge Rev / Stash  (需 mihomo >= 1.18.0)

mixed-port: 7890
port: 7891
socks-port: 7892
allow-lan: true
bind-address: '*'
mode: rule
log-level: warning
ipv6: false
unified-delay: true
tcp-concurrent: true
find-process-mode: 'off'
global-client-fingerprint: chrome

profile:
  store-selected: true
  store-fake-ip: true

tun:
  enable: true
  stack: mixed
  device: utun0
  mtu: 1400
  dns-hijack:
    - any:53
    - udp://any:53
  auto-route: true
  auto-detect-interface: true
  strict-route: false
  gso: true
  gso-max-size: 65536

sniffer:
  enable: true
  force-dns-mapping: true
  parse-pure-ip: true
  override-destination: false
  sniff:
    HTTP:
      ports: [80, 8080-8880]
      override-destination: true
    TLS:
      ports: [443, 8443]
    QUIC:
      ports: [443, 8443]

dns:
  enable: true
  listen: 0.0.0.0:1053
  ipv6: false
  enhanced-mode: fake-ip
  fake-ip-range: 198.18.0.1/16
  fake-ip-filter:
    - '*.lan'
    - '*.local'
    - '*.localdomain'
    - '+.msftconnecttest.com'
    - '+.msftncsi.com'
    - 'time.*.com'
    - 'stun.*.*'
  default-nameserver:
    - 223.5.5.5
    - 119.29.29.29
  nameserver:
    - https://1.1.1.1/dns-query
    - https://dns.alidns.com/dns-query
  proxy-server-nameserver:
    - https://1.1.1.1/dns-query
  fallback:
    - https://8.8.8.8/dns-query
    - tls://dns.google:853
  fallback-filter:
    geoip: true
    geoip-code: CN

proxies:
  - name: Oracle-4K
    type: hysteria2
    server: ${IP}
    port: ${PORT}
    ports: ${HOP/:/-}
    password: ${PASS}
    sni: ${SNI}
    skip-cert-verify: true
    alpn:
      - h3
    up: "$(calc_up)"
    down: "$(calc_down)"

proxy-groups:
  - name: 节点选择
    type: select
    proxies: [自动选择, Oracle-4K, DIRECT]

  - name: 自动选择
    type: url-test
    url: https://www.gstatic.com/generate_204
    interval: 180
    tolerance: 50
    lazy: false
    proxies: [Oracle-4K]

  - name: YouTube
    type: select
    proxies: [节点选择, Oracle-4K, 自动选择, DIRECT]

  - name: 谷歌服务
    type: select
    proxies: [节点选择, Oracle-4K, 自动选择]

  - name: 流媒体
    type: select
    proxies: [节点选择, Oracle-4K, 自动选择]

  - name: 电报
    type: select
    proxies: [节点选择, Oracle-4K]

  - name: 兜底
    type: select
    proxies: [节点选择, DIRECT]

rules:
  - DOMAIN-SUFFIX,youtube.com,YouTube
  - DOMAIN-SUFFIX,youtu.be,YouTube
  - DOMAIN-SUFFIX,googlevideo.com,YouTube
  - DOMAIN-KEYWORD,googlevideo,YouTube
  - DOMAIN-SUFFIX,ytimg.com,YouTube
  - DOMAIN-SUFFIX,youtube-nocookie.com,YouTube
  - DOMAIN-SUFFIX,ggpht.com,YouTube
  - DOMAIN-SUFFIX,googlesyndication.com,YouTube
  - DOMAIN-SUFFIX,google.com,谷歌服务
  - DOMAIN-SUFFIX,googleapis.com,谷歌服务
  - DOMAIN-SUFFIX,gstatic.com,谷歌服务
  - DOMAIN-SUFFIX,googleusercontent.com,谷歌服务
  - DOMAIN-SUFFIX,gvt1.com,谷歌服务
  - DOMAIN-SUFFIX,gvt2.com,谷歌服务
  - DOMAIN-SUFFIX,netflix.com,流媒体
  - DOMAIN-SUFFIX,nflxvideo.net,流媒体
  - DOMAIN-SUFFIX,disneyplus.com,流媒体
  - DOMAIN-SUFFIX,spotify.com,流媒体
  - DOMAIN-SUFFIX,tiktokv.com,流媒体
  - DOMAIN-SUFFIX,telegram.org,电报
  - DOMAIN-SUFFIX,t.me,电报
  - DOMAIN-SUFFIX,telesco.pe,电报
  - IP-CIDR,91.108.4.0/22,电报,no-resolve
  - IP-CIDR,149.154.160.0/20,电报,no-resolve
  - IP-CIDR,127.0.0.0/8,DIRECT,no-resolve
  - IP-CIDR,10.0.0.0/8,DIRECT,no-resolve
  - IP-CIDR,172.16.0.0/12,DIRECT,no-resolve
  - IP-CIDR,192.168.0.0/16,DIRECT,no-resolve
  - DOMAIN-SUFFIX,lan,DIRECT
  - DOMAIN-SUFFIX,local,DIRECT
  - GEOIP,CN,DIRECT,no-resolve
  - MATCH,兜底
EOF

LINK="hysteria2://${PASS}@${IP}:${PORT},${HOP/:/-}/?sni=${SNI}&insecure=1#Oracle4K"
echo "${LINK}" > "${LINKF}"
base64 -w0 "${LINKF}" > /root/sub.txt 2>/dev/null || true

printf '\n\033[1;32m================ 部署完成 ================\033[0m\n'
printf 'Clash 配置 : %s\n' "${OUT}"
printf '分享链接   : %s\n' "${LINK}"
printf '订阅(base64): %s\n' "$(cat /root/sub.txt 2>/dev/null || echo '-')"
printf '服务端配置 : /etc/hysteria/config.yaml\n'
printf '带宽参数   : up=%s mbps / down=%s mbps\n' "${UP}" "${DOWN}"
printf '\n手机导入: 把 %s 的内容复制成 .yaml 导入 Clash，或直接扫下面二维码\n\n' "${OUT}"

if ! command -v qrencode >/dev/null 2>&1; then
  DEBIAN_FRONTEND=noninteractive apt-get install -y qrencode >/dev/null 2>&1 || true
fi
if command -v qrencode >/dev/null 2>&1; then
  qrencode -t ANSIUTF8 "${LINK}" || true
fi

printf '\n自检:\n'
printf '  systemctl status hysteria-server --no-pager | head -5\n'
printf '  ss -lunp | grep %s\n' "${PORT}"
printf '  iptables -t nat -L PREROUTING -n | grep %s\n' "${PORT}"
