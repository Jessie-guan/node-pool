# 进阶版：自己搭一套每天自动更新的节点池

> 这个教程教你用 GitHub Actions（免费）搭一套流水线：
> 每天自动拉全网订阅源 → 测速筛选 → 生成配置 → 你的客户端自动更新。
>
> **不需要服务器，不需要域名，不需要花钱。**
> 需要：一个 GitHub 账号 + 15 分钟。

---

## 一、它到底在干什么

```
每天 11:17（北京时间）
   │
   ├─ 采集：20 个公开订阅源，合并去重（通常 2000-5000 个节点）
   ├─ 测速：mihomo 内核并发测延迟（100 线程，全部测完约 2 分钟）
   ├─ 测带宽：对延迟通过的节点实测下载速度，>30KB/s 才留下
   ├─ 生成：单策略组配置（PROXY，url-test 自动选优）
   └─ 提交：dist/clash.yaml 更新到你的仓库
        │
        └─ 你的客户端订阅这个文件的 raw 地址，每次打开自动拉新的
```

关键点：**在 GitHub 的国外服务器上测速**。
这些免费节点大多在海外，从国内连要过国际出口，本地测不出来；
而 GitHub runner 就在墙外，测的是真实可用性。

实测对比（同一条流水线、同样的节点源）：

| 测试环境 | 筛出的可用节点 |
|---|---|
| 国内家宽本地测 | 0–2 个 |
| GitHub runner（国外） | 16–24 个，最高 649 Mbps |

---

## 二、准备

### 2.1 你需要

```
① GitHub 账号（没有的话 https://github.com/signup 注册，1 分钟）
② 电脑一台（Windows/Mac 都行）
③ 15 分钟
```

### 2.2 检查能不能打开 GitHub

```
浏览器访问 https://github.com
能正常打开就行。打不开的话看最后一节「国内访问 GitHub」。
```

---

## 三、第一步：创建仓库

```
① 打开 https://github.com/new
② Repository name 填：node-pool
③ 选 Public（必须，公开仓库的 Actions 完全免费）
④ 不要勾 Add a README file
⑤ 点绿色按钮 Create repository
```

---

## 四、第二步：上传文件

你的压缩包里有个 `pipeline` 文件夹，里面有这些文件：

```
pipeline/
├── .github/workflows/daily.yml     ← 定时任务定义（关键）
├── run.py                          ← 主程序
├── sources.txt                     ← 订阅源清单
├── assets/
│   └── fallback.yaml               ← 兜底节点
├── dist/
│   ├── clash.yaml                  ← 输出（首次运行后更新）
│   └── sub.txt                     ← base64 版输出
└── README.md
```

### 上传方式 A：网页拖拽（推荐新手）

```
① 打开你的仓库页面
② 点「uploading an existing file」链接（在 "Quick setup" 那一块）
③ 把 pipeline 里的文件拖进去

注意：.github 和 assets 是文件夹，网页拖拽可能丢失层级。
      正确做法是先上传根目录文件，再分别进文件夹创建。
```

**更稳的方式 B：用 GitHub Desktop**

```
① 下载 https://desktop.github.com
② 登录 → Clone 你的仓库到本地
③ 把 pipeline 里的所有文件复制进去（包括隐藏的 .github 文件夹）
④ 提交 + Push
```

**最省事的方式 C：用脚本（我有现成的）**

压缩包里有个 `bootstrap-github.ps1`，双击运行，按提示粘一个 Token，它自动完成：
```
建仓库 → 上传所有文件 → 开 Actions 权限 → 触发第一次运行 → 打印订阅地址
```

Token 怎么拿：
```
https://github.com/settings/tokens
→ Generate new token (classic)
→ Note 填 dsh
→ 勾 repo 和 workflow（两个都要勾！workflow 是上传 .github/workflows 必须的）
→ Generate token → 复制 ghp_ 开头那串
```

---

## 五、第三步：启用 Actions

```
① 打开仓库的 Actions 标签页
② 如果显示 "Workflows aren't being run on this fork"
   → 点 "I understand my workflows, go ahead and enable them"
③ 左侧点 daily-node-refresh
④ 右边点 "Run workflow" → 再点绿色 "Run workflow" 按钮
⑤ 等 8–12 分钟，刷新页面看到绿色对勾 = 成功
```

---

## 六、第四步：拿订阅地址

格式是：

```
https://raw.githubusercontent.com/你的用户名/node-pool/main/dist/clash.yaml
```

比如用户名是 `zhangsan`：

```
https://raw.githubusercontent.com/zhangsan/node-pool/main/dist/clash.yaml
```

如果这个地址打不开（国内有时会被干扰），用这两个镜像：

```
https://ghfast.top/https://raw.githubusercontent.com/你的用户名/node-pool/main/dist/clash.yaml

https://cdn.jsdelivr.net/gh/你的用户名/node-pool@main/dist/clash.yaml
```

> **推荐用 jsdelivr 那个**，国内访问最稳，我实测 200ms 内打开。

---

## 七、第五步：导入客户端

### FlClash（安卓/Win/Mac 通用）

```
① 左侧「配置」→ 右上「+」→「链接」
② 长按输入框 → 粘贴订阅地址（不要手打，输入法会把标点改成全角）
③ 保存 → 卡片出现蓝勾
④ 长按卡片 → 编辑 → 自动更新 → 改成 6 小时
⑤ 仪表盘 → 启动
```

### Clash Verge Rev（Windows）

```
① 配置 → 右上 + → 远程
② 粘贴地址 → 导入
③ 右键配置卡片 → 更新间隔改成 360 分钟
④ 设置 → 打开系统代理
```

> **导入时报「安全连接失败，服务器证书可能无效」怎么办**
> 说明你现在开着代理在访问这个地址，TLS 被自己干扰了。
> 解决：先把客户端停掉（不是断开连接，是退出程序），导入成功后再启动。

---

## 八、验证是否在自动跑

```
① 打开仓库 → Actions 标签
② 应该看到每天的运行记录（绿色对勾）
③ 点进去 → 看 Artifacts 或日志里的统计：
     采集节点：2528
     清洗后可用：24
     | 649 Mbps | 48ms | US-216.106.186.33-02 |
```

---

## 九、自定义

### 9.1 改运行时间

编辑 `.github/workflows/daily.yml`：

```yaml
on:
  schedule:
    - cron: "17 3 * * *"    # UTC 3:17 = 北京时间 11:17
```

改 cron 表达式即可。北京时间 = UTC + 8，所以想每天 8 点跑就写 `0 0 * * *`。

### 9.2 加订阅源

编辑 `sources.txt`，每行一个 URL。支持三种格式：
- clash yaml（`proxies:` 结构）
- 分享链接列表（`ss://` `vmess://` `vless://` `trojan://`）
- 整段 base64

### 9.3 加自建服务器（Hysteria2）

新建 `assets/hy2.yaml`：

```yaml
proxies:
  - name: MyServer
    type: hysteria2
    server: 你的服务器IP
    port: 443
    password: 你的密码
    sni: bing.com
    skip-cert-verify: true
    up: "60 Mbps"
    down: "180 Mbps"
```

提交后，流水线会把它放在 PROXY 组**最前面**（优先使用）。

### 9.4 调整筛选门槛

编辑 `run.py` 里这一行：

```python
if bps > 30000:   # 30 KB/s 才留下
```

想更严格就改大（比如 100000 = 100KB/s）。

---

## 十、国内访问 GitHub

如果 `github.com` 打不开：

```
① 换 DNS：223.5.5.5（阿里）或 119.29.29.29（腾讯）
② 用加速镜像访问：https://ghfast.top/https://github.com
③ 手机热点试试（有时运营商线路不同）
```

`raw.githubusercontent.com` 被干扰的话，统一用 jsdelivr 镜像：

```
https://cdn.jsdelivr.net/gh/用户名/仓库@main/dist/clash.yaml
```

---

## 十一、常见问题

### Q：Actions 跑失败了，日志显示 `fatal: could not read Username`

仓库设置 → Actions → General → Workflow permissions → 选 **Read and write permissions** → Save

### Q：跑完但 dist/clash.yaml 没更新

检查 workflow 的最后一步（提交产物）有没有报错，通常是权限问题，同上。

### Q：nodes 数量是 0

说明所有订阅源都挂了（偶尔会发生）。等第二天，或者在 `sources.txt` 里加新源。

### Q：会不会产生费用

公开仓库的 Actions **完全免费，不限时长**。私有仓库每月 2000 分钟免费额度，这套跑一次约 10 分钟，也够用 200 次。

### Q：IPC 时间是多少

单次运行 8–12 分钟，主要耗在测速上（5000 个节点 × 2.5 秒超时 ÷ 100 线程）。

---

## 附：文件结构速查

```
你的仓库/
├── .github/
│   └── workflows/
│       └── daily.yml          ← 定时任务（必须有）
├── assets/
│   ├── fallback.yaml          ← 实测可用的兜底节点
│   ├── warp.yaml              ← （可选）WARP 配置
│   └── hy2.yaml               ← （可选）自建 Hysteria2
├── dist/
│   ├── clash.yaml             ← 输出：客户端订阅这个
│   └── sub.txt                ← 输出：base64 版
├── run.py                     ← 主程序
└── sources.txt                ← 订阅源清单
```
